
import 'package:flutter/material.dart';
import 'services/supabase_service.dart';
import 'pages/auth_page.dart';
import 'pages/search_page.dart';
import 'pages/offer_page.dart';
import 'pages/seller_page.dart';
import 'models.dart';
import 'repositories/offer_repository.dart';
import 'pages/nearby_page.dart';
import 'pages/plans_page.dart';
import 'pages/admin_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SupabaseService.initialize();
  runApp(const PrecoPertoApp());
}

class PrecoPertoApp extends StatelessWidget {
  const PrecoPertoApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'PreçoPerto',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final categories = const ['🛒 Produtos','🔧 Serviços','📱 Tecnologia','🏠 Casa','🚗 Automóveis','💇 Beleza'];

  @override
  Widget build(BuildContext context) {
    final pages = [_home(), const SearchPage(), const Center(child: Text('Seus favoritos aparecerão aqui.')), _account()];
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Buscar'),
          NavigationDestination(icon: Icon(Icons.favorite_border), label: 'Favoritos'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Conta'),
        ],
      ),
    );
  }

  Widget _home() => SafeArea(
    child: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('PreçoPerto', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const Text('Compare. Encontre. Economize.'),
        const SizedBox(height: 18),
        TextField(
          readOnly: true,
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage())),
          decoration: InputDecoration(
            hintText: 'O que você procura?',
            prefixIcon: const Icon(Icons.search),
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 20),
        const Text('Categorias', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: categories.map((x) => ActionChip(label: Text(x), onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage()));
        })).toList()),
        const SizedBox(height: 24),
        const Text('Ofertas em destaque', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        const OfferPreview(title: 'Instalação de ar-condicionado', price: 'R\$ 180', rating: '4,9', sponsored: true),
        const OfferPreview(title: 'Eletricista residencial', price: 'R\$ 80', rating: '4,9'),
        const OfferPreview(title: 'Smartphone 128 GB', price: 'R\$ 1.899', rating: '4,8'),
      ],
    ),
  );

  Widget _account() => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Minha conta', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 15),
      ListTile(leading: const Icon(Icons.login), title: const Text('Entrar / criar conta'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AuthPage()))),
      ListTile(leading: const Icon(Icons.storefront_outlined), title: const Text('Cadastrar serviço'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SellerPage()))),
      ListTile(leading: const Icon(Icons.location_on_outlined), title: const Text('Ofertas perto de mim'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NearbyPage()))),
      ListTile(leading: const Icon(Icons.workspace_premium_outlined), title: const Text('Planos para vendedores'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlansPage()))),
      ListTile(leading: const Icon(Icons.admin_panel_settings_outlined), title: const Text('Administração'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage()))),
    ],
  );
}

class OfferPreview extends StatelessWidget {
  final String title, price, rating;
  final bool sponsored;
  const OfferPreview({super.key, required this.title, required this.price, required this.rating, this.sponsored = false});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: const CircleAvatar(child: Icon(Icons.local_offer_outlined)),
      title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (sponsored) const Text('PATROCINADO', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
        Text(title),
      ]),
      subtitle: Text('⭐ $rating'),
      trailing: Text(price, style: const TextStyle(fontWeight: FontWeight.bold)),
      onTap: () {
        final offer = Offer(id: 'demo', title: title, price: price, seller: 'Parceiro', rating: double.tryParse(rating) ?? 0, type: 'service', sponsored: sponsored);
        Navigator.push(context, MaterialPageRoute(builder: (_) => OfferPage(offer: offer)));
      },
    ),
  );
}
